create view TMP_ORDER as
select nvl(order_moution_id,
           first_value(order_moution_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) order_moution_id,
       nvl(workplace_from_id,
           first_value(workplace_from_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) workplace_from_id,
       nvl(workplace_to_id,
           first_value(workplace_to_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) workplace_to_id,
       nvl(order_motion_state_id,
           first_value(order_motion_state_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) order_motion_state_id,
       nvl(user_send_id,
           first_value(user_send_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) user_send_id,
       nvl(user_process_id,
           first_value(user_process_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) user_process_id,
       nvl(send_date,
           first_value(send_date)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) send_date,
       nvl(process_date,
           first_value(process_date)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) process_date,
       nvl(sender_note,
           first_value(sender_note)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) sender_note,
       nvl(recipient_note,
           first_value(recipient_note)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) recipient_note,
       nvl(order_service_id,
           first_value(order_service_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) order_service_id,
       nvl(route_template_id,
           first_value(route_template_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) route_template_id,
       nvl(to_user_send_id,
           first_value(to_user_send_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) to_user_send_id,
       nvl(order_motion_reason_id,
           first_value(order_motion_reason_id)
           over(partition by ord order by id rows between unbounded
                preceding and unbounded following)) order_motion_reason_id,
       id,
       action_id,
       abonent_id,
       new_abonent_id,
       device_group_id,
       priority_id,
       old_device,
       new_device,
       old_connect_type_id,
       new_connect_type_id,
       old_address_id,
       new_address_id,
       open_date,
       close_date,
       begin_sysdate,
       end_sysdate,
       packet_type_id,
       note,
       tariff_timing_id,
       smeta,
       smeta_retax,
       amount,
       from_date,
       to_date,
       new_packet_type_id,
       town_id,
       user_id,
       nds_type_id,
       new_nds_type_id,
       discount_type_id,
       correct_order,
       link_type_id,
       order_device_state_id,
       pay_condition_id,
       is_move_account,
       operation_id,
       block_user_id,
       parent_id,
       department
  from (select *
          from (select nvl(od.parent_id, od.id) ord,
                       om.id order_moution_id,
                       om.workplace_from_id,
                       om.workplace_to_id,
                       om.order_motion_state_id,
                       om.user_send_id,
                       om.user_process_id,
                       om.send_date,
                       om.process_date,
                       om.sender_note,
                       om.recipient_note,
                       om.order_service_id,
                       om.route_template_id,
                       om.to_user_send_id,
                       om.order_motion_reason_id,
                       od.*
                  from db.order_device od, un.order_motion om
                 where od.id = om.order_device_id(+)
                 start with od.parent_id is null
                connect by prior od.id = od.parent_id)) od
 where od.process_date >= (select to_date(fvarchar, 'dd.mm.yyyy')
                             from db.report_setup
                            where id = 403)
   and od.process_date < (select to_date(fvarchar, 'dd.mm.yyyy')
                            from db.report_setup
                           where id = 404)
/

