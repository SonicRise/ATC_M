create view TMP as
select mt."ID",mt."NAME",mt."IS_DOC",mt."MONEY_SAP_ID",mt."IAS_MONEY_TYPE_ID" from db.money_type mt, db.money_type mt2
where mt.id = mt2.id
/

